//название любимого фильма;
let love_film = 'Криминальное чтиво';

//название приложения, в котором проводишь больше всего времени;
let nameProgramm = 'Visual Studio Code';

//адрес статьи про JavaScript в википедии;
let articleJS = 'https://ru.wikipedia.org/wiki/JavaScript';

//весь текст "Lorem Ipsum...(до конца)"
let lorem = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime eligendi debitis porro eaque eos, voluptatibus sequi voluptas aperiam, similique hic iusto aut! Deleniti ab eaque consectetur excepturi quidem saepe tempore.'

//
