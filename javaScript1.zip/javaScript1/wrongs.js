//1
let 1tad;

//2
let person-ted;

//3 
let 123;

//4
let -;

//5 
