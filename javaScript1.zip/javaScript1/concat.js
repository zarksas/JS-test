
/*
Создай файл all-my-skills.js и используй в нем:

переменные (let);
константы (const);
вывод в консоль;
арифметические операторы;
три вида кавычек.
*/

//Ниже приведи один пример использования null с переменной и один пример с константой.
let greetings = 'Hello World';

let result = greetings * null;
console.log(result);

const number = 2012;

const sum = number + null;
console.log(sum);





