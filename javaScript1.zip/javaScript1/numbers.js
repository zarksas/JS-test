//age
let age = 26;

//год рождения;
let year_birth = 1995;

//число рождения (без нолика в начале);
let year = 26;

//количество родных братьев;
let brothers = 2;

//количество родных сестер;
let sister = 1;

//количество человек в семье;
let numberFsmily = 6;

//стоимость проезда до места обучения;
let payment_travel = 120;

//текущий год;
let currentYear = 2022;

//курс доллара;
let dollar_exchange = 74.87;

//курс евро;
let euro_exchange = 84.91;

//курс биткоина;
let bitcoin_exchange = 3153615;


//Задача 2.2 
//текущий год минус год рождения;

let result_year = currentYear - year_birth;

//текущий год минус твой возраст;

let result_year2 = currentYear - age;

//количество родных братьев плюс количество родных сестер;

let sum_family = brothers + sister;

//курс евро умноженный на 1000; 
let multiply_1 = euro_exchange * 1000;

//курс доллара умноженный на 2.5;
let multiply_2 = dollar_exchange * 2.5;

//курс биткоина разделенный на 10000;
let division = bitkoin_exchange / 10000;

//стоимость проезда до места обучения разделенная на курс доллара;
let division_travel = payment_travel / dollar_exchange;

//количество человек в семье минус количество братьев минус количество сестер;
let minus_family = numberFsmily - brothers - sister;

//0 деленный на твой возраст;
let division_zero = 0 / age;

//35 минус твой возраст;
let minus_age = 35 - age;