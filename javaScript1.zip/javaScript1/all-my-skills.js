/*
Создай файл all-my-skills.js и используй в нем:

переменные (let);
константы (const);
вывод в консоль;
арифметические операторы;
три вида кавычек.
*/

let parametr1 = 2095;

let parametr2 = 6808;

const number = 8934;

const film = 'Pulp Fiction';

console.log(film);

console.log(parametr1 * number);

console.log(film + ' ');

console.log("\"it's my life `  \" ");

