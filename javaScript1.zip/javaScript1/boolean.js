let current_year = 2022;

if (currentYear = 2022) {
    console.log(currentYear)
} 


const iAmAStudent = true;
const isSpring = false
const javaSciptIsBeauty = true
const constCanBeChanged = false
const letCanBeChanged = true
const nullIsADataType = true
const nullIsAValue = true
const iAmFromGrozny = false
